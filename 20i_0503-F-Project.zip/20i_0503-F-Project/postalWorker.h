#pragma once
#include <iostream>
#include "postman.h"
#include "clerk.h"
#include "accountOfficer.h"
using namespace std;

//inheriting from several classes protected and public members
class postalWorker:public postman, public clerk, public officer {
private:



public:
	postalWorker();
	//void virtual getDetails() const = 0; //pure vitual

};