#pragma once
#include <iostream>
using namespace std;

//employee class
class clerk {
protected:
	string userName;
	string password;
	string age;
	string salary;
	static int noOfClerks;
public:
	clerk();
	void set_clerkName(string);
	void set_password(string);
	void set_age(string);
	void set_salary(string);
	string get_userName();
	string get_password();
	string get_age();
	string get_salary();
	static int get_noOfClerks();
	void login();
	void virtual getDetails();
};