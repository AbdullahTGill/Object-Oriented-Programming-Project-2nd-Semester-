#include <iostream>
#include <fstream>
#include "order.h"
using namespace std;

order::order() {
	this->i = new invoice(); //composition

}

void order::addOrder() {
	//******************
	string ID;
	string weight;
	string length;
	string height;
	string width;
	string shipTime;
	int phone;
	string add;
	//******************
	address d1;
	ofstream fout;
	//******************

	fout.open("ParcelDetails.txt", ios::app);
	if (fout.fail()) {
		cout << "Could not open the file" << endl;
	}

	fout << "********Enter the customer's Order Details*********" << endl;
	cout << "Enter your Order ID: " << endl;
	cin >> ID;
	i->set_orderID(ID);
	fout << "Order ID: ";
	fout << ID;
	fout << endl;
	cout << "Enter the weight of the parcel: " << endl;
	cin >> weight;
	i->set_weight(weight);
	fout << "Weight: ";
	fout << weight;
	fout << endl;
	cout << "Enter the length: " << endl;
	cin >> length;
	i->set_length(length);
	fout << "Length: ";
	fout << length;
	fout << endl;
	cout << "Enter the height: " << endl;
	cin >> height;
	i->set_height(height);
	fout << "Height: ";
	fout << height;
	fout << endl;
	cout << "Enter the width: " << endl;
	cin >> width;
	i->set_width(width);
	fout << "Width: ";
	fout << width;
	fout << endl;
	cout << "Enter the shipment time: " << endl;
	cin >> shipTime;
	i->set_time(shipTime);
	fout << "Shipment Time: ";
	fout << shipTime;
	fout << endl;
	cout << "Enter your phone no: " << endl;
	cin >> phone;
	fout << "Phone No: ";
	fout << phone;
	fout << endl;
	d1.set_contactNo(phone);
	cout << endl;
	cout << "Enter your address: " << endl;
	cin >> add;
	d1.set_address(add);
	fout << "Address: ";
	fout << add;
	fout.close(); //file closing

	cout << "Invoice Generated...." << endl;

}

//destructor
order::~order() {
	delete i;
}