#pragma once
#include <iostream>
#include "address.h"
using namespace std;

class invoice {
private:
	string orderID;
	string weight;
	string length;
	string height;
	string width;
	string shipmentTime;
	address senderadd;
	address recieveradd;
public:
	invoice();
	//setters
	void set_orderID(string ID);
	void set_weight(string w);
	void set_length(string l);
	void set_height(string h);
	void set_width(string wi);
	void set_time(string t);
	//getters
	string get_orderID();
	string get_weight();
	string get_length();
	string get_height();
	string get_width();
	string get_time();

	void getDetails();
};