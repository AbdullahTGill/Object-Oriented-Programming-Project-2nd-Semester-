#include<iostream>
#include"postalWorker.h"

postalWorker::postalWorker() {

}