#pragma once
#include <iostream>
#include "postalWorker.h"
using namespace std;

class postOffice {
private:
	postalWorker* worker;
	string city;


public:
	postOffice();
	void IslamabadpostOffice();
	void LahorepostOffice();
	void KarachipostOffice();

	void dailyReport();
	void sorting(); //will sort on the basis of cities and sent to the GPO of that city
	~postOffice();
		
};