#include <iostream>
#include <fstream>
#include <string>
#include "customer.h"
using namespace std;

customer::customer() {
	custName = " ";
	custAddress = {" ", 0 };
	this->Order = new order();
}

customer::customer(string n, address a) {
	custName = n;
	custAddress = a;
	this->Order = new order();
}

//file writing
void customer::registration() { 
	address d1;
	ofstream fout;
	int phone;
	string add;
	fout.open("CustomerRegistration.txt", ios::app);
	fout << "********REGISTRATION FOR CUSTOMERS*********" << endl;
	cout << "Enter your name: " << endl;
	cin >> custName;
	fout << custName;
	fout << endl;
	cout << "Enter your phone no: " << endl;
	cin >> phone;
	fout << phone;
	fout << endl;
	d1.set_contactNo(phone);
	cout << endl;
	cout << "Enter your address: " << endl;
	cin >> add;
	d1.set_address(add);
	fout << add;
	fout.close(); //file closing
}

void customer::login() {
	bool userFound=false;
	bool passFound=false;
	fstream fin;
	string match_user;
	string pass;
	fin.open("CustomerLogin.txt", ios::in);
rep:
	cout << "Enter your username: " << endl;
	cin >> custName;

	fin >> match_user;
	while ((!fin.eof()) && match_user!=custName) {
		fin >> match_user;
	}
		userFound =!fin.eof();
		if (userFound == true) {
			goto next;
		}
		else {
			cout << "Incorrect Username, Enter username again! " << endl;
			goto rep;
		}

	next:
		cout << "Enter your password: " << endl;
		cin >> password;

		fin >> pass;
		while ((!fin.eof()) && pass != password) {
			fin >> pass;
		}

		passFound = !fin.eof();
		if (passFound == true)
			cout << "Logging in..." << endl;
		else {
			cout << "Incorrect password, Enter again!" << endl;
			goto next;

		}

}

//file reading
void customer::getDetails() {
	ifstream fin;
	string add;
	string name;
	int no=0;
	int num=0;
	fin.open("CustomerRegistration.txt", ios::in);
	cout << "Customer details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}
	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;

}

customer::~customer() {
	delete Order;
}