#pragma once
#include <iostream>
#include "invoice.h"
using namespace std;

class order {
private:
	invoice* i; //composition

public:
	order();
	void addOrder();
	~order();

};