#include <iostream>
#include <fstream>
#include "invoice.h"
using namespace std;

//constructor
invoice::invoice() {
	orderID = "";
	weight = "";
	length = "";
	height = "";
	width = "";
	shipmentTime = "";
	senderadd = { "",0 };
	recieveradd = { "", 0 };
}

//setters & getters
void invoice::set_orderID(string ID) {
	orderID = ID;
}

void invoice::set_weight(string w) {
	weight = w;
}

void invoice::set_length(string l) {
	length = l;
}

void invoice::set_height(string h) {
	height = h;
}

void invoice::set_width(string wi) {
	width = wi;
}

void invoice::set_time(string t) {
	shipmentTime = t;
}

string invoice::get_orderID() {
	return orderID;
}

string invoice::get_weight() {
	return weight;
}

string invoice::get_length() {
	return length;
}

string invoice::get_height() {
	return height;
}

string invoice::get_width() {
	return width;
}

string invoice::get_time() {
	return shipmentTime;
}

//file reading
void invoice::getDetails() {
	ifstream fin;
	string add;
	string name;
	int no = 0;
	int num = 0;
	fin.open("ParcelDetails.txt", ios::in);
	cout << "Parcel details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}
	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;
}
