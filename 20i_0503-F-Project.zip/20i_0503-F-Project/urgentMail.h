#pragma once
#include <iostream>
#include "invoice.h"
using namespace std;

class urgentMail {
protected:
	invoice* umail;
	int ucharges;
public:
	urgentMail(invoice*, int);
	//virtual int calculate();


};