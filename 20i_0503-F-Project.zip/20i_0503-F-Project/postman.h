#pragma once
#include <iostream>
using namespace std;

class postman {
protected:
	string postName;
	string age;
	string city;
public:
	postman();
	void virtual getDetails(); //polymorphism

};