#pragma once
#include <iostream>
#include "address.h"
#include "order.h"
using namespace std;

class customer {
private:
	string custName;
	address custAddress;
	string password;
	order* Order; //for composition
public:
	customer();
	customer(string, address);
	void registration();
	void login();
	virtual void getDetails();
	~customer();

};