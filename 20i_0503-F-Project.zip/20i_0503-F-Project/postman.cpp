#include <iostream>
#include <fstream>
#include "postman.h"
using namespace std;


postman::postman() {
	postName = "";
    age = "";
	city = "";
}

void postman::getDetails() {
	ifstream fin;
	string name;
	int no = 0;
	int num = 0;
	fin.open("PostmanDetails.txt", ios::in);
	cout << "Postman details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}

	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;
}