#pragma once
#include <iostream>
using namespace std;

class officer {
protected:
	double amountCollected;
	int stampsSold;

public:
	officer();

};