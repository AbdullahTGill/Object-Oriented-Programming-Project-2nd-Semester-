#include <iostream>
#include <fstream>
#include "clerk.h"
using namespace std;

int clerk::noOfClerks = 6;

clerk::clerk() {
	userName = "";
	password = "";

}

//setters & getters
void clerk::set_clerkName(string c) {
	userName = c;
}

void clerk::set_password(string p) {
	password = p;
}

void clerk::set_age(string a) {
	age = a;
}

void clerk::set_salary(string s) {
	salary = s;
}

string clerk::get_userName() {
	return userName;
}

string clerk::get_password() {
	return password;
}

string clerk::get_age() {
	return age;
}

string clerk::get_salary() {
	return salary;
}

int clerk::get_noOfClerks() {
	return noOfClerks;
}

//login system for the employee
void clerk::login() {
	bool userFound = false;
	bool passFound = false;
	fstream fin;
	string match_user;
	string pass;
	fin.open("EmployeeLogin.txt", ios::in);
rep:
	cout << "Enter your username: " << endl;
	cin >> userName;

	fin >> match_user;
	while ((!fin.eof()) && match_user != userName) {
		fin >> match_user;
	}
	userFound = !fin.eof();
	if (userFound == true) {
		goto next;
	}
	else {
		cout << "Incorrect Username, Enter username again! " << endl;
		goto rep;
	}

next:
	cout << "Enter your password: " << endl;
	cin >> password;

	fin >> pass;
	while ((!fin.eof()) && pass != password) {
		fin >> pass;
	}

	passFound = !fin.eof();
	if (passFound == true)
		cout << "Logging in..." << endl;
	else {
		cout << "Incorrect password, Enter again!" << endl;
		goto next;

	}
}

void clerk::getDetails() {
	ifstream fin;
	string add;
	string name;
	int no = 0;
	int num = 0;
	fin.open("EmployeeDetails.txt", ios::in);
	cout << "Customer details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}
	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;
}