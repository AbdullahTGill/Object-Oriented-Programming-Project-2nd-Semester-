#include <iostream>
#include "accountOfficer.h"
using namespace std;

officer::officer() {

}