#pragma once
#include <iostream>
using namespace std;

class address {
private:
	string Address;
	int contactNo;
	//postal office location
public:
	address();
	address(string, int);
	void set_address(string a);
	string get_address();
	void set_contactNo(int c);
	int get_contactNo();
};