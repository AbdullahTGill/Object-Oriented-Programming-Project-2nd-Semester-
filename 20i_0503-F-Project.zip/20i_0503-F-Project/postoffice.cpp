#include <iostream>
#include <fstream>
#include <string>
#include "postoffice.h"
using namespace std;

postOffice::postOffice() {
	this->worker = new postalWorker();
}

postOffice::~postOffice() {
	delete worker;
}

//reading data from 3 major post offices
void postOffice::IslamabadpostOffice() {
	ifstream fin;
	string add;
	string name;
	int no = 0;
	int num = 0;
	fin.open("IslamabadPostOffice.txt", ios::in);
	cout << "Islamabad Postoffice details are as follows: " << endl;

	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}

	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;
}

void postOffice::LahorepostOffice() {
	ifstream fin;
	string add;
	string name;
	int no = 0;
	int num = 0;
	fin.open("LahorePostOffice.txt", ios::in);
	cout << "Lahore Postoffice details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}
	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;
}

void postOffice::KarachipostOffice() {
	ifstream fin;
	string add;
	string name;
	int no = 0;
	int num = 0;
	fin.open("KarachiPostOffice.txt", ios::in);
	cout << "Karachi Postoffice details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}
	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;
}

void postOffice::sorting() {
	ifstream fin;
	ofstream f1, f2, f3, f4;
	string islo, lhr, mul, khr;
	bool cityFound = false;

	fin.open("AllMails.txt", ios::in);

	if (fin.fail()) {

		cout << "Could not open the file" << endl;
	}

	f1.open("ToIslamabad.txt", ios::app);
	f2.open("ToLahore.txt", ios::app);
	f3.open("ToKarachi.txt", ios::app);
	f4.open("ToMultan.txt", ios::app);

	f1 << "***SORTED ISLAMABAD MAILS***";
	f1 << endl;
	f2 << "***SORTED LAHORE MAILS***";
	f2 << endl;
	f3 << "***SORTED KARACHI MAILS***";
	f3 << endl;
	f4 << "***SORTED MULTAN MAILS***";
	f4 << endl;


	//***ISLAMABAD SORTING***
	while (!fin.eof()) {
		getline(fin, islo);
		if (islo.substr(0, 13) == "-To-Islamabad") {
			cityFound = true;
		}

		else if (islo.substr(0, 4) == "-To-") {
			cityFound = false;
		}

		if (cityFound == true) {
			f1 << islo;
			f1 << endl;
		}
	}

	fin.close();
	f1.close();

	cityFound = false;

	//***LAHORE SORTING***
	fin.open("AllMails.txt", ios::in);
	while (!fin.eof()) {
		getline(fin, lhr);
		if (lhr.substr(0, 10) == "-To-Lahore") {
			cityFound = true;
		}

		else if (lhr.substr(0, 4) == "-To-") {
			cityFound = false;
		}

		if (cityFound == true) {
			f2 << lhr;
			f2 << endl;
		}
	}

	fin.close();
	f2.close();

	cityFound = false;

	//***Karachi SORTING***
	fin.open("AllMails.txt", ios::in);
	while (!fin.eof()) {
		getline(fin, khr);
		if (khr.substr(0, 11) == "-To-Karachi") {
			cityFound = true;
		}

		else if (khr.substr(0, 4) == "-To-") {
			cityFound = false;
		}

		if (cityFound == true) {
			f3 << khr;
			f3 << endl;
		}
	}

	fin.close();
	f3.close();

	cityFound = false;

	//***Multan SORTING***
	fin.open("AllMails.txt", ios::in);
	while (!fin.eof()) {
		getline(fin, mul);
		if (mul.substr(0, 10) == "-To-Multan") {
			cityFound = true;
		}

		else if (mul.substr(0, 4) == "-To-") {
			cityFound = false;
		}

		if (cityFound == true) {
			f4 << mul;
			f4 << endl;
		}
	}

	fin.close();
	f3.close();
}