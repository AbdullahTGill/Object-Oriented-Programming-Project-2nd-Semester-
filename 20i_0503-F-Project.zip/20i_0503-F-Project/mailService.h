#pragma once
#include<iostream>
#include "urgentMail.h"
#include "regularMail.h"
using namespace std;

class mailService:public regularMail, public urgentMail {
private:



public:
	mailService();
	void UrgentMailDetails();
	void RegularMailDetails();

};