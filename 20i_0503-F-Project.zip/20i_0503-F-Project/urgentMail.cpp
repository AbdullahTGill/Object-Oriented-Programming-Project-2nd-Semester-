#include <iostream>
#include "urgentMail.h"
using namespace std;

urgentMail::urgentMail(invoice* umail, int u) {
	this->umail = umail; //aggregation
}

/*
int urgentMail::calculate() {
	if (umail->get_weight() == "250gm")
		return 51;

	else if (umail->get_weight() == "500gm")
		return 64;

	else if (umail->get_weight() == "1000gm")
		return 26;
}
*/
