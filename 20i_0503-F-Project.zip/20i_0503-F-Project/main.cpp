#include <iostream>
#include "customer.h"
#include "address.h"
#include "invoice.h"
#include "clerk.h"
#include "postman.h"
#include "postoffice.h"
#include "GPO.h"
#include "mailService.h"
#include "postalWorker.h"
using namespace std;

int main() {

	customer c1;
	invoice i1;
	clerk e1;
	postman p1;
	postOffice o1;
	order d1;
	GPO g1;
	//mailService s1;
	postalWorker w1;
	int choice;

	//*************MENU*************

		menu:
		cout << '\t' << " \t Welcome to Pakistan Post Courier Service" << endl;
		cout << '\t' << "MENU" << endl;
		cout << '\t' << "1.Employee" << endl;
		cout << '\t' << "2.Customer" << endl;
		cout << '\t' << "3.Exit" << endl;

		cout << "Enter the choice you want to select (1-3)" << endl;
		cin >> choice;

		switch (choice) {
		case 1:
			emp:
			cout << '\t' << "1.Login" << endl;
			cout << '\t' << "2.Head" << endl;
			cout << '\t' << "3.Postman" << endl;
			cout << '\t' << "4.Clerk" << endl;
			cout << '\t' << "5.GPO" << endl;
			cout << '\t' << "6.Back to main menu" << endl;

			cout << "Enter the choice you want to select (1-6)" << endl;
			cin >> choice;

			if (choice == 1) {
				w1.login();
				goto emp;
			}
			else if (choice == 2) {
				cout << '\t' << "1.Islamabad Postoffice Details" << endl;
				cout << '\t' << "2.Lahore Postoffice Details" << endl;
				cout << '\t' << "3.Karachi Postoffice Details" << endl;
				cout << '\t' << "4.Sort Mails" << endl;
				cout << '\t' << "5.Go back" << endl;

				cout << "Enter the choice you want to select (1-4)" << endl;
				cin >> choice;
				if (choice == 1)
					o1.IslamabadpostOffice();
				else if (choice == 2)
					o1.LahorepostOffice();
				else if (choice == 3)
					o1.KarachipostOffice();
				else if (choice == 4)
					o1.sorting();
				else if (choice == 5)
					goto emp;

			}

			else if (choice == 3) {
				p1.getDetails();
				goto emp;
			}

			else if (choice == 4) {
				e1.getDetails();
				goto emp;
			}

			else if (choice == 5) {
				cout << '\t' << "1.Add Employee" << endl;
				cout << '\t' << "2.Delete Employee" << endl;
				cout << '\t' << "3.Go back" << endl;

				cout << "Enter the choice you want to select (1-3)" << endl;
				cin >> choice;

				if (choice == 1)
					g1.addEmployee();
				else if (choice == 2)
					g1.deleteEmployee();
				else if (choice == 3)
					goto emp;
			}
			else if (choice == 6)
				goto menu;

		case 2:
			cust:
			cout << '\t' << "1.Login" << endl;
			cout << '\t' << "2.Register" << endl;
			cout << '\t' << "3.Details" << endl;
			cout << '\t' << "4.Place Order" << endl;
			cout << '\t' << "5.Invoice" << endl;
			cout << '\t' << "6.Main menu" << endl;
			cout << "Enter the choice you want to select (1-6)" << endl;
			cin >> choice;

			if (choice == 1) {
				c1.login();
				goto cust;
			}
			else if (choice == 2) {
				c1.registration();
				goto cust;
			}
			else if (choice == 3) {
				c1.getDetails();
				goto cust;
			}
			else if (choice == 4) {
				d1.addOrder();
				goto cust;
			}
			else if (choice == 5) {
				i1.getDetails();
				goto cust;
			}
			else if (choice == 6)
				goto menu;


		case 3:
			exit(0);

		}

	return 0;
}