#include <iostream>
#include"regularMail.h"
using namespace std;


regularMail::regularMail(invoice* mail, int c) {
	this->mail = mail; //aggregation
	charges = c;
}

/*
int regularMail::calculate() {
	if (mail->get_weight() == "1Kg") 
		return 100;

	else if (mail->get_weight() == "3Kg")
		return 175;

	else if (mail->get_weight() == "5Kg")
		return 250;

	else if (mail->get_weight() == "10Kg")
		return 375;

	else if (mail->get_weight() == "15Kg")
		return 500;

	else if (mail->get_weight() == "20Kg")
		return 625;

	else if (mail->get_weight() == "25Kg")
		return 750;

	else if (mail->get_weight() == "30Kg")
		return 875;
		
}

*/