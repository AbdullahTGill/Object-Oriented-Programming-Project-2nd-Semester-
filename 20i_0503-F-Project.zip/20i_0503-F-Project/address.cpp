#include <iostream>
#include "address.h"
using namespace std;

address::address() {
	Address = "";
	contactNo = 0;
}

address::address(string a, int c) {
	Address = a;
	contactNo = c;
}

void address::set_address(string a) {
    Address = a;
}

void address::set_contactNo(int c) {
	contactNo = c;
}

int address::get_contactNo() {
	return contactNo;
}

string address::get_address() {
	return Address;
}