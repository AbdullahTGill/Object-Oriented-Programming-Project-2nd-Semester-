#pragma once
#include<iostream>
#include "postoffice.h"
using namespace std;

class GPO {
private:
	postalWorker* worker;
public:
	GPO();
	void addEmployee();
	void UpdateEmployee();
	void deleteEmployee();



};