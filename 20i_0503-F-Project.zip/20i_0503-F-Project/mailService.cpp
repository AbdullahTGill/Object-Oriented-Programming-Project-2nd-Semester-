#include <iostream>
#include <string>
#include <fstream>
#include "mailService.h"

using namespace std;

/*
void mailService::RegularMailDetails() {

	ifstream fin;
	string add;
	string name;
	int no = 0;
	int num = 0;
	fin.open("CustomerRegistration.txt", ios::in);
	cout << "Customer details are as follows: " << endl;
	if (fin.fail()) {
		cout << "Could not open the file" << endl;
	}
	fin >> name;
	while (!fin.eof()) {
		cout << name << endl;
		fin >> name;
	}
	cout << name;

}

void mailService::UrgentMailDetails() {

}
*/