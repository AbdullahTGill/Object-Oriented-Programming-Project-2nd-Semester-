#include <iostream>
#include <fstream>
#include "GPO.h"
using namespace std;

GPO::GPO() {
	worker = new postalWorker();
}

void GPO::addEmployee() {
	string empName;
	string empAge;
	string empSalary;
	ofstream fout;

	fout.open("EmployeeDetails.txt", ios::app);

	cout << "***Enter the employee's details you wish to add***" << endl;
	cout << "Enter the employee's name: " << endl;
	cin >> empName;
	worker->set_clerkName(empName);
	fout << endl;
	fout << "Name: ";
	fout << empName;
	fout << endl;
	cout << "Enter the employee's age: " << endl;
	cin >> empAge;
	worker->set_age(empAge);
	fout << "Age: ";
	fout << empAge;
	fout << endl;
	cout << "Enter the employee's salary: " << endl;
	cin >> empSalary;
	worker->set_salary(empSalary);
	fout << "Salary: ";
	fout << empSalary;
	fout << endl;
	fout.close(); //file closing

}

void GPO::UpdateEmployee() {

}

void GPO::deleteEmployee() {
	delete worker;
}

