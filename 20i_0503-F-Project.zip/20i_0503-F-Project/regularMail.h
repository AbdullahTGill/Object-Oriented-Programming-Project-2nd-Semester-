#pragma once
#include <iostream>
#include "invoice.h"
using namespace std;


class regularMail {
protected:
	invoice* mail;
	int charges;

public:
	regularMail(invoice*, int);
	//virtual void getDetails();
	//virtual int calculate();



};